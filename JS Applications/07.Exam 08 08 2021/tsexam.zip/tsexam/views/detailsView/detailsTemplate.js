import { html } from './../../node_modules/lit-html/lit-html.js';

// za proba start
// export let detailsTemplate = () => html`
//  <div>detailsTemplate is working</div>
// `;
// za proba end

// da vnimavam s / / href="/edit/${item._id}"

// _id,   // 
//     title,    //   //
//     description, //   // 
//     imageUrl,   //
//     type, 
// _createdOn: 1616162253496
// _id: "3987279d-0ad4-4afb-8ca9-5b256ae3b298"
// _ownerId:

//todo
export let detailsTemplate = (item, deleteHandler, isOwner, likeHandler, canLike, bookLikes) => html`
 
 <section id="details-page" class="details">
            <div class="book-information">
                <h3>${item.title}</h3>
                <p class="type">Type: ${item.type}</p>
                <p class="img"><img src=${item.imageUrl}></p>
                <div class="actions">
                    <!-- Edit/Delete buttons ( Only for creator of this book )  -->
                    

    ${isOwner
      ? html`  
     <a class="button" href="/edit/${item._id}">Edit</a>
     <a class="button" href="javascript:void(0);" @click=${deleteHandler}>Delete</a>
      `
      : html``}  

                    <!-- Bonus -->
                    <!-- Like button ( Only for logged-in users, which is not creators of the current book ) -->
                    <!-- ( for Guests and Users )  -->
                    
                     ${canLike
                    ?  html`
                    <a class="button" href="javascript:void(0);" @click=${likeHandler}>Like</a>
                     ` 
                    : html`
                     <div class="likes">
                        <img class="hearts" src="/images/heart.png">
                        <span id="total-likes">Likes: ${bookLikes}</span>
                    </div>
                     ` 
                     }
                    
  
                </div>
            </div>
            <div class="book-description">
                <h3>Description:</h3>
                <p>${item.description}</p>
            </div>
        </section> 
 
`;




// <!-- Bonus -->
//                     <!-- Like button ( Only for logged-in users, which is not creators of the current book ) -->
//                     <a class="button" href="#">Like</a>

//                     <!-- ( for Guests and Users )  -->
//                     <div class="likes">
//                         <img class="hearts" src="/images/heart.png">
//                         <span id="total-likes">Likes: 0</span>
//                     </div>
                    
//                      ${canLike
//                     ?  html`
//                     <a class="btn btn-primary" href="javascript:void(0);" @click=${likeHandler}>Like</a>
//                      ` 
//                     : html`
//                      <span class="enrolled-span" >Liked ${movieLikes}</span>
//                      ` 
//                      }




// old
// export let detailsTemplate = (item, deleteHandler, isOwner) => html`
 
//  <section id="listing-details">
//     <h1>Details</h1>
//     <div class="details-info">
//         <img src=${item.imageUrl}>
//         <hr>
//         <ul class="listing-props">
//             <li><span>Brand:</span>${item.brand}</li>
//             <li><span>Model:</span>${item.model}</li>
//             <li><span>Year:</span>${item.year}</li>
//             <li><span>Price:</span>${item.price}$</li>
//         </ul>

//         <p class="description-para">${item.description}</p>

//         ${isOwner
//         ? html`
//         <div class="listings-buttons">
//             <a href="/edit/${item._id}" class="button-list">Edit</a>
//             <a href="javascript:void(0);" @click=${deleteHandler} class="button-list">Delete</a>
//         </div>`
//         : '' }        }

        
//     </div>
// </section>
// `;

// export let detailsTemplate = (item, deleteHandler, isOwner) => html`
 
//  <div class="row space-top">
//             <div class="col-md-12">
//                 <h1>CUCI    Furniture Details</h1>
//             </div>
//  </div>


//     <div class="row space-top">
//     <div class="col-md-4">
//                 <div class="card text-white bg-primary">
//                     <div class="card-body">
//                         <img src=${item.img} />
//                     </div>
//                </div>
//             </div> 

//             <div class="col-md-4">
//                 <p>Make: <span>${item.make}</span></p>
//                 <p>Model: <span>${item.model}</span></p>
//                 <p>Year: <span>${item.year}</span></p>
//                 <p>Description: <span>${item.description}</span></p>
//                 <p>Price: <span>${item.price}</span></p>
//                 <p>Material: <span>${item.material}</span></p>

//             ${isOwner 
//                 ? html`
//                 <div>
//                     <a href="/edit/${item._id}" class="btn btn-info">Edit</a>
//                     <a href="javascript:void(0);" @click=${deleteHandler} class="btn btn-red">Delete</a>
//                 </div>`
//                 : ''}
                
//             </div>
            
//    </div>
// `;


